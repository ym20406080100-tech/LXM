package com.lxm.mapper

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 10, 18)
    private val panel = Color.rgb(28, 22, 39)
    private val purple = Color.rgb(174, 92, 255)
    private val white = Color.rgb(245, 240, 250)
    private val prefs by lazy { getSharedPreferences("lxm_settings", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 28)
        }
        scroll.addView(root)
        setContentView(scroll)

        val logo = TextView(this).apply {
            text = "LXM"
            textSize = 38f
            setTextColor(purple)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        root.addView(logo, matchWrap())
        val subtitle = TextView(this).apply {
            text = "KEY MAPPER  •  CONTROL CENTER"
            textSize = 12f
            setTextColor(white)
            gravity = Gravity.CENTER
            setPadding(0, 2, 0, 24)
        }
        root.addView(subtitle, matchWrap())

        addSection(root, "AIM CONTROL", "Manual tuning only — this does not move your aim automatically.")
        addSlider(root, "Sensitivity", "sensitivity", 1, 100, 50)
        addSlider(root, "Vertical pull setting", "vertical", 0, 100, 35)
        addSlider(root, "Pointer speed", "pointer", 1, 10, 5)

        addSection(root, "MAPPER SETTINGS", "Configure the values you use with supported mouse/keyboard apps.")
        val toggle = Switch(this).apply {
            text = "Enable saved LXM profile"
            textSize = 15f
            setTextColor(white)
            isChecked = prefs.getBoolean("profile_enabled", false)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("profile_enabled", checked).apply()
                Toast.makeText(this@MainActivity,
                    if (checked) "Profile saved as enabled" else "Profile disabled",
                    Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(toggle, matchWrap())

        val save = Button(this).apply {
            text = "SAVE SETTINGS"
            setTextColor(Color.WHITE)
            setBackgroundColor(purple)
            setOnClickListener {
                Toast.makeText(this@MainActivity, "Settings are saved on this device", Toast.LENGTH_SHORT).show()
            }
        }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = 24
        root.addView(save, lp)

        val note = TextView(this).apply {
            text = "NOTE\nAndroid does not let an ordinary app change PUBG's internal aim or recoil. LXM stores local tuning values; actual mouse mapping requires compatible input hardware/app permissions."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(14, 18, 14, 18)
            setBackgroundColor(panel)
        }
        val noteLp = LinearLayout.LayoutParams(-1, -2)
        noteLp.topMargin = 18
        root.addView(note, noteLp)
    }

    private fun addSection(root: LinearLayout, title: String, desc: String) {
        val heading = TextView(this).apply {
            text = title
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(purple)
            setPadding(0, 18, 0, 5)
        }
        root.addView(heading, matchWrap())
        val description = TextView(this).apply {
            text = desc
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, 10)
        }
        root.addView(description, matchWrap())
    }

    private fun addSlider(root: LinearLayout, label: String, key: String, min: Int, max: Int, default: Int) {
        val holder = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 10)
            setBackgroundColor(panel)
        }
        val title = TextView(this).apply {
            setTextColor(white)
            textSize = 14f
            text = "$label: ${prefs.getInt(key, default)}"
        }
        holder.addView(title, matchWrap())
        val seek = SeekBar(this).apply {
            this.max = max - min
            progress = (prefs.getInt(key, default) - min).coerceIn(0, max - min)
            progressTintList = android.content.res.ColorStateList.valueOf(purple)
            thumbTintList = android.content.res.ColorStateList.valueOf(purple)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val value = p + min
                    title.text = "$label: $value"
                    prefs.edit().putInt(key, value).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        holder.addView(seek, matchWrap())
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = 10
        root.addView(holder, lp)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
